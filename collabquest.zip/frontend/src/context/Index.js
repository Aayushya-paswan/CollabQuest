// Export everything from UserInfo
export { default as UserContext, useUser, UserProvider } from './UserInfo';

// Default export for convenience
export { default } from './UserInfo';
