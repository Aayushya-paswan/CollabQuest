import React from 'react'
import './Home.css'
import Navbar from '../Navbar/Navbar';
function Home() {
  return (
    <>
    <Navbar/>
    <div className='home'>Home</div>
    </>
  )
}

export default Home